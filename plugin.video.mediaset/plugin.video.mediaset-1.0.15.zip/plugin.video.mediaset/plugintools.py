# -*- coding: utf-8 -*-

#---------------------------------------------------------------------------

# Plugin Tools v2.0.0

#---------------------------------------------------------------------------

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

# Based on code from youtube, parsedom and pelisalacarta addons

# Author: 

# JesÃºs and modified by Titan

# tvalacarta@gmail.com

# http://www.mimediacenter.info/plugintools

#---------------------------------------------------------------------------

# Changelog:

# 1.0.0

# - First release

# 1.0.1

# - If find_single_match can't find anything, it returns an empty string

# - Remove addon id from this module, so it remains clean

# 1.0.2

# - Added parameter on "add_item" to say that item is playable

# 1.0.3

# - Added direct play

# - Fixed bug when video isPlayable=True

# 1.0.4

# - Added get_temp_path, get_runtime_path, get_data_path

# - Added get_setting, set_setting, open_settings_dialog and get_localized_string

# - Added keyboard_input

# - Added message

# 1.0.5

# - Added read_body_and_headers for advanced http handling

# - Added show_picture for picture addons support

# - Added optional parameters "title" and "hidden" to keyboard_input

# 1.0.6

# - Added fanart, show, episode and infolabels to add_item

# 1.0.7

# - Added set_view function

# 1.0.8

# - Added selector

# 2.0.0

# Welcome matrix

#---------------------------------------------------------------------------



import xbmc
import xbmcvfs
import xbmcplugin

import xbmcaddon

import xbmcgui



import urllib.request, urllib.parse, urllib.error 

import re

import sys

import os

import time

import socket

import hashlib

from io import StringIO

import gzip  

import requests



module_log_enabled = False

http_debug_log_enabled = False



LIST = "list"

THUMBNAIL = "thumbnail"

MOVIES = "movies"

TV_SHOWS = "tvshows"

SEASONS = "seasons"

EPISODES = "episodes"

OTHER = "other"



# Suggested view codes for each type from different skins (initial list thanks to xbmcswift2 library)

ALL_VIEW_CODES = {

    'list': {

        'skin.confluence': 50, # List

        'skin.aeon.nox': 50, # List

        'skin.droid': 50, # List

        'skin.quartz': 50, # List

        'skin.re-touched': 50, # List

    },

    'thumbnail': {

        'skin.confluence': 500, # Thumbnail

        'skin.aeon.nox': 500, # Wall

        'skin.droid': 51, # Big icons

        'skin.quartz': 51, # Big icons

        'skin.re-touched': 500, #Thumbnail

    },

    'movies': {

        'skin.confluence': 515, # Thumbnail 515, # Media Info 3

        'skin.aeon.nox': 500, # Wall

        'skin.droid': 51, # Big icons

        'skin.quartz': 52, # Media info

        'skin.re-touched': 500, #Thumbnail

    },

    'tvshows': {

        'skin.confluence': 515, # Thumbnail 515, # Media Info 3

        'skin.aeon.nox': 500, # Wall

        'skin.droid': 51, # Big icons

        'skin.quartz': 52, # Media info

        'skin.re-touched': 500, #Thumbnail

    },

    'seasons': {

        'skin.confluence': 50, # List

        'skin.aeon.nox': 50, # List

        'skin.droid': 50, # List

        'skin.quartz': 52, # Media info

        'skin.re-touched': 50, # List

    },

    'episodes': {

        'skin.confluence': 503, # Media Info

        'skin.aeon.nox': 518, # Infopanel

        'skin.droid': 50, # List

        'skin.quartz': 52, # Media info

        'skin.re-touched': 550, # Wide

    },

}



# Write something on XBMC log

def log(message):

    xbmc.log(message)



# Write this module messages on XBMC log

def _log(message):

    if module_log_enabled:

        xbmc.log("plugintools."+message)



# Parse XBMC params - based on script.module.parsedom addon    

def get_params():

    _log("get_params")

    

    param_string = sys.argv[2]

    

    _log("get_params "+str(param_string))

    

    commands = {}



    if param_string:

        split_commands = param_string[param_string.find('?') + 1:].split('&')

    

        for command in split_commands:

            _log("get_params command="+str(command))

            if len(command) > 0:

                if "=" in command:

                    split_command = command.split('=')

                    key = split_command[0]

                    value = urllib.parse.unquote_plus(split_command[1])

                    commands[key] = value

                else:

                    commands[command] = ""

    

    _log("get_params "+repr(commands))

    return commands



# Fetch text content from an URL

def read(url):

    _log("read "+url)



    f = urllib.request.urlopen(url)

    data = f.read()

    f.close()

    

    return data



def read_body_and_headers(url, post=None, headers=[], follow_redirects=False, timeout=None):

    _log("read_body_and_headers "+url)



    if post is not None:

        _log("read_body_and_headers post="+post)



    if len(headers)==0:

        headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0"])



    # Start cookie lib

    ficherocookies = os.path.join( get_data_path(), 'cookies.dat' )

    _log("read_body_and_headers cookies_file="+ficherocookies)



    cj = None

    ClientCookie = None

    cookielib = None



    # Let's see if cookielib is available

    try:

        _log("read_body_and_headers importing cookielib")

        import http.cookiejar

    except ImportError:

        _log("read_body_and_headers cookielib no disponible")

        # If importing cookielib fails

        # let's try ClientCookie

        try:

            _log("read_body_and_headers importing ClientCookie")

            import ClientCookie

        except ImportError:

            _log("read_body_and_headers ClientCookie not available")

            # ClientCookie isn't available either

            urlopen = urllib.request.urlopen

            Request = urllib.request.Request

        else:

            _log("read_body_and_headers ClientCookie available")

            # imported ClientCookie

            urlopen = ClientCookie.urlopen

            Request = ClientCookie.Request

            cj = ClientCookie.MozillaCookieJar()



    else:

        _log("read_body_and_headers cookielib available")

        # importing cookielib worked

        urlopen = urllib.request.urlopen

        Request = urllib.request.Request

        cj = http.cookiejar.MozillaCookieJar()

        # This is a subclass of FileCookieJar

        # that has useful load and save methods



    if cj is not None:

    # we successfully imported

    # one of the two cookie handling modules

        _log("read_body_and_headers Cookies enabled")



        if os.path.isfile(ficherocookies):

            _log("read_body_and_headers Reading cookie file")

            # if we have a cookie file already saved

            # then load the cookies into the Cookie Jar

            try:

                cj.load(ficherocookies)

            except:

                _log("read_body_and_headers Wrong cookie file, deleting...")

                os.remove(ficherocookies)



        # Now we need to get our Cookie Jar

        # installed in the opener;

        # for fetching URLs

        if cookielib is not None:

            _log("read_body_and_headers opener using urllib2 (cookielib)")

            # if we use cookielib

            # then we get the HTTPCookieProcessor

            # and install the opener in urllib2

            if not follow_redirects:

                opener = urllib.request.build_opener(urllib.request.HTTPHandler(debuglevel=http_debug_log_enabled),urllib.request.HTTPCookieProcessor(cj),NoRedirectHandler())

            else:

                opener = urllib.request.build_opener(urllib.request.HTTPHandler(debuglevel=http_debug_log_enabled),urllib.request.HTTPCookieProcessor(cj))

            urllib.request.install_opener(opener)



        else:

            _log("read_body_and_headers opener using ClientCookie")

            # if we use ClientCookie

            # then we get the HTTPCookieProcessor

            # and install the opener in ClientCookie

            try:

                opener = ClientCookie.build_opener(ClientCookie.HTTPCookieProcessor(cj))

                ClientCookie.install_opener(opener)

            except AttributeError:

                pass    



    # -------------------------------------------------

    # Cookies instaladas, lanza la peticiÃ³n

    # -------------------------------------------------



    # Contador 



    # Diccionario para las cabeceras

    txheaders = {}



    # Construye el request

    if post is None:

        _log("read_body_and_headers GET request")

    else:

        _log("read_body_and_headers POST request")

    

    # AÃ±ade las cabeceras

    _log("read_body_and_headers ---------------------------")

    for header in headers:

        _log("read_body_and_headers header %s=%s" % (str(header[0]),str(header[1])) )

        txheaders[header[0]]=header[1]

    _log("read_body_and_headers ---------------------------")



    req = Request(url, post, txheaders)

    if timeout is None:

        handle=urlopen(req)

    else:        

        #Disponible en python 2.6 en adelante --> handle = urlopen(req, timeout=timeout)

        #Para todas las versiones:

        try:

            import socket

            deftimeout = socket.getdefaulttimeout()

            socket.setdefaulttimeout(timeout)

            handle=urlopen(req)            

            socket.setdefaulttimeout(deftimeout)

        except:

            import sys

            for line in sys.exc_info():

                _log( "%s" % line )

    

    # Actualiza el almacÃ©n de cookies

    cj.save(ficherocookies)



    # Lee los datos y cierra

    if handle.info().get('Content-Encoding') == 'gzip':

        buf = StringIO( handle.read())

        f = gzip.GzipFile(fileobj=buf)

        data = f.read()

    else:

        data=handle.read()



    info = handle.info()

    _log("read_body_and_headers Response")



    returnheaders=[]

    _log("read_body_and_headers ---------------------------")

    for header in info:

        _log("read_body_and_headers "+header+"="+info[header])

        returnheaders.append([header,info[header]])

    handle.close()

    _log("read_body_and_headers ---------------------------")



    '''

    # Lanza la peticiÃ³n

    try:

        response = urllib2.urlopen(req)

    # Si falla la repite sustituyendo caracteres especiales

    except:

        req = urllib2.Request(url.replace(" ","%20"))

    

        # AÃ±ade las cabeceras

        for header in headers:

            req.add_header(header[0],header[1])



        response = urllib2.urlopen(req)

    '''

     

    return data,returnheaders



class NoRedirectHandler(urllib.request.HTTPRedirectHandler):

    def http_error_302(self, req, fp, code, msg, headers):

        infourl = urllib.addinfourl(fp, headers, req.get_full_url())

        infourl.status = code

        infourl.code = code

        return infourl

    http_error_300 = http_error_302

    http_error_301 = http_error_302

    http_error_303 = http_error_302

    http_error_307 = http_error_302



# Parse string and extracts multiple matches using regular expressions



def find_single_match(text, pattern, index=0, flags=re.DOTALL):

    try:

        matches = re.findall(pattern, text, flags)

        return matches[index]

    except Exception:

        return ''





def find_multiple_matches(text, pattern, flags=re.DOTALL):

    return re.findall(pattern, text, flags)



def add_item( action="" , title="" , plot="" , url="" , thumbnail="" , fanart="" , show="" , episode="" , extra="", page="", info_labels = None, isPlayable = False , folder=True, ref_id="", context_menu=None ):

    _log("add_item action=["+action+"] title=["+title+"] url=["+url+"] thumbnail=["+thumbnail+"] fanart=["+fanart+"] show=["+show+"] episode=["+episode+"] extra=["+extra+"] page=["+page+"] isPlayable=["+str(isPlayable)+"] folder=["+str(folder)+"]")



    listitem = xbmcgui.ListItem( title ) 

    listitem.setArt({ 'poster': 'poster.png', 'banner' : 'banner.png' })

    listitem.setArt({'icon': thumbnail, 'thumb': thumbnail, 'poster': thumbnail,

                             'fanart': fanart}) 

    if info_labels is None:

        info_labels = { "Title" : title, "FileName" : title, "Plot" : plot }

    listitem.setInfo( "video", info_labels )



    if context_menu:

        listitem.addContextMenuItems(context_menu)



    if fanart!="":

        listitem.setProperty('fanart_image',fanart)

        xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

    

    if url.startswith("plugin://"):

        itemurl = url

        listitem.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)

    elif isPlayable:

        listitem.setProperty("Video", "true")

        listitem.setProperty('IsPlayable', 'true')

        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s&ref_id=%s' % ( sys.argv[ 0 ] , action , urllib.parse.quote_plus( title ) , urllib.parse.quote_plus(url) , urllib.parse.quote_plus( thumbnail ) , urllib.parse.quote_plus( plot ) , urllib.parse.quote_plus( extra ) , urllib.parse.quote_plus( page ) , urllib.parse.quote_plus( ref_id ))

        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)

    else:

        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s&ref_id=%s' % ( sys.argv[ 0 ] , action , urllib.parse.quote_plus( title ) , urllib.parse.quote_plus(url) , urllib.parse.quote_plus( thumbnail ) , urllib.parse.quote_plus( plot ) , urllib.parse.quote_plus( extra ) , urllib.parse.quote_plus( page ) , urllib.parse.quote_plus( ref_id ))

        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)


def build_plugin_url(action="", title="", url="", thumbnail="", plot="", extra="", page="", ref_id=""):
    """Build a plugin:// callback URL using the same param scheme as add_item(), for
    use in context menu RunPlugin() calls."""
    return '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s&ref_id=%s' % (
        sys.argv[0], action, urllib.parse.quote_plus(title), urllib.parse.quote_plus(url),
        urllib.parse.quote_plus(thumbnail), urllib.parse.quote_plus(plot),
        urllib.parse.quote_plus(extra), urllib.parse.quote_plus(page), urllib.parse.quote_plus(ref_id)
    )


def close_item_list():

    _log("close_item_list")



    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)

def encode_headers(headers: dict) -> str:
    return urllib.parse.urlencode(headers)

_VTT_TIME_RE = re.compile(
    r'(?:(\d{1,2}):)?(\d{2}):(\d{2})\.(\d{3})\s*-->\s*(?:(\d{1,2}):)?(\d{2}):(\d{2})\.(\d{3})'
)

def _format_vtt_time(total_seconds):
    if total_seconds < 0:
        total_seconds = 0
    whole = int(total_seconds)
    ms = round((total_seconds - whole) * 1000)
    if ms == 1000:
        ms = 0
        whole += 1
    h, rem = divmod(whole, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"

def _shift_vtt_content(text, offset_seconds):
    def repl(match):
        h1, m1, s1, ms1, h2, m2, s2, ms2 = match.groups()
        start = (int(h1 or 0) * 3600) + (int(m1) * 60) + int(s1) + int(ms1) / 1000.0
        end = (int(h2 or 0) * 3600) + (int(m2) * 60) + int(s2) + int(ms2) / 1000.0
        return f"{_format_vtt_time(start + offset_seconds)} --> {_format_vtt_time(end + offset_seconds)}"
    return _VTT_TIME_RE.sub(repl, text)

def _get_subtitle_offset():
    try:
        raw = get_setting('subtitle_offset')
        return float(raw) if raw not in (None, '') else 0.0
    except Exception:
        return 0.0

def _shift_subtitle_url(url, offset_seconds, headers=None):
    """
    Download a WebVTT subtitle file and shift its cue timestamps by offset_seconds,
    returning a local file path. inputstream.adaptive presents a timeline rebased
    to 0 for this addon's HLS streams, but the VTT cues are authored against the
    stream's original (non-zero-based) timestamps, so they need a fixed correction
    to land in sync; see resources/settings.xml "subtitle_offset".
    """
    try:
        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=15) as resp:
            text = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        _log(f"_shift_subtitle_url: download failed for [{url}]: {e}")
        return url

    shifted = _shift_vtt_content(text, offset_seconds)

    temp_dir = xbmcvfs.translatePath('special://temp/plugin.video.mediaset/')
    xbmcvfs.mkdirs(temp_dir)
    local_path = os.path.join(temp_dir, f"sub_{abs(hash(url))}.vtt")
    try:
        with open(local_path, 'w', encoding='utf-8') as f:
            f.write(shifted)
    except Exception as e:
        _log(f"_shift_subtitle_url: could not write [{local_path}]: {e}")
        return url

    return local_path

_M3U8_VARIANT_RE = re.compile(r'#EXT-X-STREAM-INF:(?P<attrs>[^\n]*)\n(?P<uri>[^\n#][^\n]*)')
_M3U8_BANDWIDTH_RE = re.compile(r'BANDWIDTH=(\d+)')
_M3U8_SEPARATE_TRACK_RE = re.compile(r'#EXT-X-MEDIA:TYPE=(?:AUDIO|SUBTITLES)[^\n]*URI="[^"]+"')

def _get_quality_mode():
    try:
        return 'force' if get_setting('quality_mode') == '1' else 'auto'
    except Exception:
        return 'auto'

def _pick_highest_variant_url(master_url, headers=None):
    """
    Fetch an HLS master playlist and return the absolute URL of its highest-
    BANDWIDTH variant. inputstream.adaptive has no chooser mode that forces
    max quality regardless of screen size or measured bandwidth - only ways
    to cap it lower ('fixed-res' adapts to screen, 'adaptive' adapts to
    bandwidth) - so the only reliable way to force it is to hand ISA a
    manifest with just one rendition to begin with. Returns None (caller
    falls back to normal master-playlist playback) if the manifest can't be
    fetched/parsed, or if audio/subtitles are a separate track referenced by
    the master (this shortcut only works when audio is muxed into each video
    variant; a separate track's group linkage only exists at the master level
    and would silently disappear if we hand ISA just one variant playlist -
    this is exactly what live channels' embedded subtitle track needs).
    """
    try:
        req = urllib.request.Request(master_url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=15) as resp:
            text = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        _log(f"_pick_highest_variant_url: download failed for [{master_url}]: {e}")
        return None

    if _M3U8_SEPARATE_TRACK_RE.search(text):
        _log("_pick_highest_variant_url: manifest has a separate audio/subtitle track, skipping")
        return None

    best_bandwidth, best_uri = -1, None
    for match in _M3U8_VARIANT_RE.finditer(text):
        bw_match = _M3U8_BANDWIDTH_RE.search(match.group('attrs'))
        if not bw_match:
            continue
        bandwidth = int(bw_match.group(1))
        if bandwidth > best_bandwidth:
            best_bandwidth, best_uri = bandwidth, match.group('uri').strip()

    if not best_uri:
        return None

    return urllib.parse.urljoin(master_url, best_uri)

def play_resolved_url(url, subtitles=None, headers=None, is_live=False):
    """
    Play a video URL in Kodi with optional subtitles (with names) and headers.
    is_live=True enables inputstream.adaptive's timeshift buffer, so a live
    channel can be paused/rewound instead of only supporting live-edge playback.
    """
    _log(f"play_resolved_url [{url}]")

    if _get_quality_mode() == 'force':
        forced_url = _pick_highest_variant_url(url, headers)
        if forced_url:
            url = forced_url

    header_str = encode_headers(headers) if headers else None

    # Route through inputstream.adaptive instead of Kodi's built-in ffmpeg HLS
    # demuxer. The raw demuxer re-derives the stream's PTS offset on every seek
    # or pause/resume, which loses sync with externally attached (setSubtitles)
    # subtitles until playback is fully restarted. inputstream.adaptive keeps a
    # single normalized timeline that survives those events.
    use_isa = False
    try:
        import inputstreamhelper
        isa_helper = inputstreamhelper.Helper('hls')
        use_isa = isa_helper.check_inputstream()
    except Exception as e:
        _log(f"inputstreamhelper unavailable, falling back to direct playback: {e}")

    # Headers go on the URL itself too: some inputstream.adaptive versions only
    # apply the stream_headers property to segment/license sub-requests and fetch
    # the initial manifest using the bare path, so the CDN's Referer/User-Agent
    # check on that first request 403s without this.
    if header_str:
        url = f"{url}|{header_str}"

    listitem = xbmcgui.ListItem(path=url)

    if use_isa:
        listitem.setMimeType('application/vnd.apple.mpegurl')
        listitem.setContentLookup(False)
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # Default ISA behavior ('adaptive') picks a rendition based on measured
        # bandwidth and can settle below the best available quality, unlike the
        # old raw ffmpeg playback which always grabbed the highest-bandwidth
        # variant. 'fixed-res' instead picks the best resolution that fits the
        # display, matching the old always-max-quality behavior.
        listitem.setProperty('inputstream.adaptive.stream_selection_type', 'fixed-res')
        if is_live:
            # Without this, ISA only keeps the live edge and Kodi shows just
            # play/stop. This makes it accumulate a rewindable buffer instead,
            # so pause/seek-back/catch-up work like a normal video.
            listitem.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        if header_str:
            # manifest_headers covers the master AND every child .m3u8 variant
            # playlist; stream_headers covers only the actual media segments.
            # common_headers (Kodi v22+) unifies both but older ISA ignores it,
            # so all three are set to cover whichever the running version reads.
            listitem.setProperty('inputstream.adaptive.manifest_headers', header_str)
            listitem.setProperty('inputstream.adaptive.stream_headers', header_str)
            listitem.setProperty('inputstream.adaptive.common_headers', header_str)

    listitem.setProperty('IsPlayable', 'true')

    # Add subtitles properly with names
    if subtitles:
        offset = _get_subtitle_offset()
        if offset:
            subtitles = [_shift_subtitle_url(u, offset, headers) for u in subtitles]
        listitem.setSubtitles(subtitles)

    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def play_widevine_url(url, license_url, subtitles=None, headers=None):
    """Play a Widevine-protected DASH manifest through inputstream.adaptive."""
    _log(f"play_widevine_url [{url}]")
    import inputstreamhelper
    if not inputstreamhelper.Helper('mpd', drm='com.widevine.alpha').check_inputstream():
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())

    header_str = encode_headers(headers) if headers else ''
    listitem = xbmcgui.ListItem(path=url)
    listitem.setMimeType('application/dash+xml')
    listitem.setContentLookup(False)
    listitem.setProperty('inputstream', 'inputstream.adaptive')
    listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    listitem.setProperty('inputstream.adaptive.stream_selection_type', 'fixed-res')
    listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    lic_headers = '&'.join(filter(None, [header_str, 'Content-Type=application/octet-stream']))
    listitem.setProperty('inputstream.adaptive.license_key', f"{license_url}|{lic_headers}|R{{SSM}}|")
    if header_str:
        listitem.setProperty('inputstream.adaptive.manifest_headers', header_str)
        listitem.setProperty('inputstream.adaptive.stream_headers', header_str)
        listitem.setProperty('inputstream.adaptive.common_headers', header_str)
    listitem.setProperty('IsPlayable', 'true')

    if subtitles:
        offset = _get_subtitle_offset()
        if offset:
            subtitles = [_shift_subtitle_url(u, offset, headers) for u in subtitles]
        listitem.setSubtitles(subtitles)

    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def _sanitize_filename(title):
    # Strip Kodi label markup tags (e.g. [B], [COLOR white]) and filesystem-unsafe chars.
    stripped = re.sub(r'\[/?[A-Za-z]+[^\]]*\]', '', title or '')
    stripped = re.sub(r'[\\/:*?"<>|]', '_', stripped).strip()
    return stripped or 'download'


def content_id_for(url, ref_id=""):
    """
    Build a stable, filesystem-safe identifier for a piece of content (movie, series
    episode, miniseries episode, etc.) from its API reference id and/or page url, so
    each one gets its own unique download subfolder and can be looked up again later
    regardless of title (which can repeat across episodes/seasons).
    """
    basis = ref_id or url or "item"
    slug_source = (url or ref_id or "item").rstrip('/').split('/')[-1] or "item"
    slug = re.sub(r'[^A-Za-z0-9._-]+', '_', slug_source)[:60]
    digest = hashlib.sha1(basis.encode('utf-8')).hexdigest()[:10]
    return f"{slug}_{digest}"


def _content_download_dir(content_id):
    dest_root = get_setting('download_path')
    if not dest_root or not content_id:
        return None
    return dest_root.rstrip('/') + '/' + content_id + '/'


def find_downloaded_media(content_id):
    """Return (video_path, [subtitle_paths]) already downloaded for content_id, or
    (None, []) if nothing has been downloaded for it yet."""
    dest_dir = _content_download_dir(content_id)
    if not dest_dir or not xbmcvfs.exists(dest_dir):
        return None, []

    _, files = xbmcvfs.listdir(dest_dir)
    video_path = None
    subtitle_paths = []
    for f in files:
        if f.startswith('video.') and not f.endswith('.part'):
            video_path = dest_dir + f
        elif f.startswith('subtitle_') and f.endswith('.vtt'):
            subtitle_paths.append(dest_dir + f)

    return video_path, sorted(subtitle_paths)


def play_local_file(path, subtitles=None):
    _log(f"play_local_file [{path}]")

    listitem = xbmcgui.ListItem(path=path)
    listitem.setProperty('IsPlayable', 'true')
    if subtitles:
        listitem.setSubtitles(subtitles)

    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def save_subtitles(dest_dir, subtitles, headers=None):
    """Save subtitle track urls as subtitle_N.vtt next to a downloaded video."""
    for index, sub_url in enumerate(subtitles or []):
        try:
            sub_resp = requests.get(sub_url, headers=headers or {}, timeout=15)
            sub_resp.raise_for_status()
            sub_file = xbmcvfs.File(dest_dir + f'subtitle_{index}.vtt', 'w')
            try:
                sub_file.write(sub_resp.content)
            finally:
                sub_file.close()
        except Exception as e:
            # Subtitles are a nice-to-have; don't fail the whole download over one.
            _log(f"save_subtitles: could not download subtitle [{sub_url}]: {e}")


def _download_lock_key(content_id):
    return f"mediaset.downloading.{content_id}"


def download_hls_stream(manifest_url, title, content_id, headers=None, subtitles=None, is_live=False):
    """
    Download an HLS stream (progressive or master playlist) to a unique subfolder
    (named after content_id) under the folder configured in the addon settings
    ("download_path"), which can be any Kodi VFS location (local path or a network
    share such as smb://) since writes go through xbmcvfs. Segments are concatenated
    in playlist order into a single output file; encrypted (#EXT-X-KEY) segments and
    separate audio/subtitle tracks are not supported. Subtitle track urls, if any,
    are downloaded alongside the video so find_downloaded_media() can pick them up.
    """
    # Kodi's home window survives across plugin invocations, so it works as a
    # cross-process "already downloading" flag (and resets on Kodi restart).
    home = xbmcgui.Window(10000)
    lock_key = _download_lock_key(content_id)
    if home.getProperty(lock_key):
        _log(f"download_hls_stream: already downloading [{content_id}]")
        xbmcgui.Dialog().notification(__settings__.getAddonInfo('name'), f"Ya se esta descargando: {title}", xbmcgui.NOTIFICATION_INFO)
        return False
    home.setProperty(lock_key, '1')
    try:
        return _download_hls_stream(manifest_url, title, content_id, headers, subtitles, is_live)
    finally:
        home.clearProperty(lock_key)


def _download_hls_stream(manifest_url, title, content_id, headers, subtitles, is_live):
    name = __settings__.getAddonInfo('name')

    def notify_error(msg):
        xbmcgui.Dialog().notification(name, msg, xbmcgui.NOTIFICATION_ERROR)

    if is_live:
        notify_error("No se pueden descargar canales en directo")
        return False

    dest_dir = _content_download_dir(content_id)
    if not dest_dir:
        xbmcgui.Dialog().ok(name, "Configura primero una carpeta de descargas en los ajustes del addon.")
        return False

    headers = headers or {}

    try:
        playlist_url = manifest_url
        resp = requests.get(playlist_url, headers=headers, timeout=15)
        resp.raise_for_status()
        text = resp.text
    except Exception as e:
        _log(f"download_hls_stream: could not fetch manifest [{manifest_url}]: {e}")
        notify_error("No se pudo descargar el manifiesto del video")
        return False

    if '#EXT-X-STREAM-INF' in text:
        variant_url = _pick_highest_variant_url(playlist_url, headers)
        if not variant_url:
            match = _M3U8_VARIANT_RE.search(text)
            variant_url = urllib.parse.urljoin(playlist_url, match.group('uri').strip()) if match else None

        if not variant_url:
            _log("download_hls_stream: could not find a downloadable variant in master playlist")
            notify_error("No se encontro ningun stream descargable")
            return False

        playlist_url = variant_url
        try:
            resp = requests.get(playlist_url, headers=headers, timeout=15)
            resp.raise_for_status()
            text = resp.text
        except Exception as e:
            _log(f"download_hls_stream: could not fetch variant playlist [{playlist_url}]: {e}")
            notify_error("No se pudo descargar la lista de variantes")
            return False

    key_match = re.search(r'#EXT-X-KEY:(?!METHOD=NONE)[^\n]*', text)
    if key_match:
        _log("download_hls_stream: stream is encrypted (#EXT-X-KEY), cannot download")
        notify_error("El video esta cifrado y no se puede descargar")
        return False

    init_match = re.search(r'#EXT-X-MAP:URI="([^"]+)"', text)
    init_uri = urllib.parse.urljoin(playlist_url, init_match.group(1)) if init_match else None

    segment_uris = [
        urllib.parse.urljoin(playlist_url, line.strip())
        for line in text.splitlines()
        if line.strip() and not line.strip().startswith('#')
    ]

    if not segment_uris:
        _log("download_hls_stream: no segments found in media playlist")
        notify_error("No se encontraron segmentos de video")
        return False

    ext = '.mp4' if init_uri else '.ts'
    dest_path = dest_dir + 'video' + ext
    # Write to a .part file and rename at the end, so find_downloaded_media()
    # never picks up (and plays) a copy that is still being written.
    part_path = dest_path + '.part'

    if not xbmcvfs.exists(dest_dir):
        xbmcvfs.mkdirs(dest_dir)

    # DialogProgressBG is a non-modal "toast"-style progress bar: it never blocks
    # the rest of the Kodi UI, so the user can navigate away (i.e. hide it) while
    # the download keeps running, unlike the modal xbmcgui.DialogProgress.
    progress = xbmcgui.DialogProgressBG()
    progress.create(name, f"Descargando {title}")

    ok = True
    try:
        out_file = xbmcvfs.File(part_path, 'w')
        try:
            if init_uri:
                init_resp = requests.get(init_uri, headers=headers, timeout=15)
                init_resp.raise_for_status()
                out_file.write(init_resp.content)

            total = len(segment_uris)
            for index, seg_url in enumerate(segment_uris):
                progress.update(int(index * 100 / total), message=f"Segmento {index + 1}/{total}")

                seg_resp = requests.get(seg_url, headers=headers, timeout=30)
                seg_resp.raise_for_status()
                out_file.write(seg_resp.content)
        finally:
            out_file.close()
    except Exception as e:
        _log(f"download_hls_stream: error downloading segments: {e}")
        ok = False
    finally:
        progress.close()

    if not ok:
        xbmcvfs.delete(part_path)
        xbmcgui.Dialog().notification(name, f"Descarga fallida: {title}", xbmcgui.NOTIFICATION_WARNING)
        return False

    save_subtitles(dest_dir, subtitles, headers)

    if not xbmcvfs.rename(part_path, dest_path):
        _log(f"download_hls_stream: could not rename [{part_path}] -> [{dest_path}]")
        xbmcvfs.delete(part_path)
        return False

    xbmcgui.Dialog().notification(name, f"Descarga completada: {title}", xbmcgui.NOTIFICATION_INFO)
    return True


def direct_play(url):

    _log("direct_play ["+url+"]")



    title = ""



    try:

        xlistitem = xbmcgui.ListItem( title,  path=url)

    except:

        xlistitem = xbmcgui.ListItem( title,  )

    xlistitem.setInfo( "video", { "Title": title } )



    playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )

    playlist.clear()

    playlist.add( url, xlistitem )



    player_type = xbmc.PLAYER_CORE_AUTO

    xbmcPlayer = xbmc.Player( player_type )

    xbmcPlayer.play(playlist)



def show_picture(url):



    local_folder = os.path.join(get_data_path(),"images")

    if not os.path.exists(local_folder):

        try:

            os.mkdir(local_folder)

        except:

            pass

    local_file = os.path.join(local_folder,"temp.jpg")



    # Download picture

    urllib.request.urlretrieve(url, local_file)

    

    # Show picture

    xbmc.executebuiltin( "SlideShow("+local_folder+")" )



def get_temp_path():

    _log("get_temp_path")


    try:
        dev = xbmc.translatePath( "special://temp/" )
    except:
        dev = xbmcvfs.translatePath( "special://temp/" )
    _log("get_temp_path ->'"+str(dev)+"'")



    return dev



def get_runtime_path():

    _log("get_runtime_path")


    try:
        dev = xbmc.translatePath( __settings__.getAddonInfo('Path') )
    except:
        dev = xbmcvfs.translatePath( __settings__.getAddonInfo('Path') )
    _log("get_runtime_path ->'"+str(dev)+"'")



    return dev



def get_data_path():

    _log("get_data_path")


    try:
         dev = xbmc.translatePath( __settings__.getAddonInfo('Profile') )
    except:
         dev = xbmcvfs.translatePath( __settings__.getAddonInfo('Profile') )
    

    # Parche para XBMC4XBOX

    if not os.path.exists(dev):

        os.makedirs(dev)



    _log("get_data_path ->'"+str(dev)+"'")



    return dev



def get_setting(name):

    _log("get_setting name='"+name+"'")



    dev = __settings__.getSetting( name )



    _log("get_setting ->'"+str(dev)+"'")



    return dev



def set_setting(name,value):

    _log("set_setting name='"+name+"','"+value+"'")



    __settings__.setSetting( name,value )



def open_settings_dialog():

    _log("open_settings_dialog")



    __settings__.openSettings()



def get_localized_string(code):

    _log("get_localized_string code="+str(code))



    dev = __language__(code)



    try:

        dev = dev.encode("utf-8")

    except:

        pass



    _log("get_localized_string ->'"+dev+"'")



    return dev



def keyboard_input(default_text="", title="", hidden=False):

    _log("keyboard_input default_text='"+default_text+"'")



    keyboard = xbmc.Keyboard(default_text,title,hidden)

    keyboard.doModal()

    

    if (keyboard.isConfirmed()):

        tecleado = keyboard.getText()

    else:

        tecleado = ""



    _log("keyboard_input ->'"+tecleado+"'")



    return tecleado



def message(text1, text2="", text3=""):

    _log("message text1='"+text1+"', text2='"+text2+"', text3='"+text3+"'")



    if text3=="":

        xbmcgui.Dialog().ok( text1 , text2 )

    elif text2=="":

        xbmcgui.Dialog().ok( "" , text1 )

    else:

        xbmcgui.Dialog().ok( text1 , text2 , text3 )



def message_yes_no(text1, text2="", text3=""):

    _log("message_yes_no text1='"+text1+"', text2='"+text2+"', text3='"+text3+"'")



    if text3=="":

        yes_pressed = xbmcgui.Dialog().yesno( text1 , text2 )

    elif text2=="":

        yes_pressed = xbmcgui.Dialog().yesno( "" , text1 )

    else:

        yes_pressed = xbmcgui.Dialog().yesno( text1 , text2 , text3 )



    return yes_pressed



def entitiesfix(string):

    string = string.decode("utf-8")

    string = string.replace("&aacute", "&aacute;")

    string = string.replace("&eacute", "&eacute;")

    string = string.replace("&iacute", "&iacute;")

    string = string.replace("&oacute", "&oacute;")

    string = string.replace("&uacute", "&uacute;")

    string = string.replace("&Aacute", "&Aacute;")

    string = string.replace("&Eacute", "&Eacute;")

    string = string.replace("&Iacute", "&Iacute;")

    string = string.replace("&Oacute", "&Oacute;")

    string = string.replace("&Uacute", "&Uacute;")

    string = string.replace("&uuml", "&uuml;")

    string = string.replace("&Uuml", "&Uuml;")

    string = string.replace("&ntilde", "&ntilde;")

    string = string.replace("&#191", "&#191;")

    string = string.replace("&#161", "&#161;")

    string = string.replace(";;", ";")

    return string



def decodeHtmlentities(string): 

    string = entitiesfix(string)

    entity_re = re.compile("&(#?)(\d{1,5}|\w{1,8});")



    def substitute_entity(match):

        if sys.version_info[0] >= 3:

            from html.entities import name2codepoint as n2cp

        else:

            from htmlentitydefs import name2codepoint as n2cp

        ent = match.group(2)

        if match.group(1) == "#":

            ent = chr(int(ent)).encode('utf-8')

            if sys.version_info[0] >= 3 and isinstance(ent, bytes):

                ent = ent.decode("utf-8")

            return ent

        else:

            cp = n2cp.get(ent)



            if cp:

                cp = chr(cp).encode('utf-8')

                if sys.version_info[0] >= 3 and isinstance(cp, bytes):

                    cp = cp.decode("utf-8")

                return cp

            else:

                return match.group()



    return entity_re.subn(substitute_entity, string)[0]

def selector(option_list,title="Select one"):

    _log("selector title='"+title+"', options="+repr(option_list))



    dia = xbmcgui.Dialog()

    selection = dia.select(title,option_list)



    return selection



def set_view(view_mode, view_code=0):

    _log("set_view view_mode='"+view_mode+"', view_code="+str(view_code))



    # Set the content for extended library views if needed

    if view_mode==MOVIES:

        _log("set_view content is movies")

        xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )

    elif view_mode==TV_SHOWS:

        _log("set_view content is tvshows")

        xbmcplugin.setContent( int(sys.argv[1]) ,"tvshows" )

    elif view_mode==SEASONS:

        _log("set_view content is seasons")

        xbmcplugin.setContent( int(sys.argv[1]) ,"seasons" )

    elif view_mode==EPISODES:

        _log("set_view content is episodes")

        xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )



    # Note: we intentionally do NOT call Container.SetViewMode here.
    # Forcing a view on every directory fights the view the user picked
    # manually and made Kodi flip between List/Iconwall/etc. on every
    # navigation. Setting the content type above is enough for the skin
    # to pick sensible defaults while still letting Kodi remember the
    # user's own view choice per window/content type.



f = open( os.path.join( os.path.dirname(__file__) , "addon.xml") )

data = f.read()

f.close()

 



__settings__ = xbmcaddon.Addon()

__language__ = __settings__.getLocalizedString


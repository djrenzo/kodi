# TorBox Kodi Addon - Quick Start

This is the fast onboarding companion to `DEVELOPMENT_KNOWLEDGE.md`.

## What This Addon Does
`plugin.video.torbox` browses and plays TorBox WebDAV media in Kodi, supports multi-account setup, library export (STRM/NFO), overrides, and subtitle workflows.

## Read These Files First
1. `addon.py` - action router + Kodi list UI orchestration.
2. `torbox_common.py` - shared constants/settings/accounts/helpers.
3. `torbox_text.py` - all user-facing strings + setup HTML templates.
4. `torbox_setup.py` - QR + local phone setup server.
5. `torbox_webdav.py` - PROPFIND + WebDAV parse/auth URL logic.
6. `torbox_library.py` - export and Kodi source creation.
7. `torbox_subtitles.py` - subtitle search/download/persistence.

## Action Routing Map
Main actions handled by `router()` in `addon.py`:
- `root`
- `browse`
- `library_browse`
- `play`
- `identify_library`
- `set_override`
- `add_subtitles`
- `view_overrides`
- `add_account`
- `settings`
- `refresh`
- `export_library`
- `export_item`
- `download_item`
- `cleanup_library`
- `reconnect_log`

## Data Locations
- Settings schema: `resources/settings.xml`
- Manual overrides: profile `overrides.json` (accessed via `load_overrides` / `save_overrides`)
- Library export root: addon setting `library_path`
- Download root: addon setting `download_path` (local or `smb://`, written via `xbmcvfs`)

## Current Conventions
- Keep orchestration in `addon.py`.
- Put shared helpers in `torbox_common.py`.
- Keep user-facing text/templates in `torbox_text.py`.
- Do not hardcode UI text in feature modules.
- Preserve current Kodi action query format.

## Setup Flow (Phone)
1. User selects add account.
2. QR opens phone page on `http://<local-ip>:8765`.
3. User submits URL/username/password.
4. Credentials persist to `account{n}_*` settings.
5. Setup server shuts down.

Notes:
- Setup page is polished and responsive.
- Existing URL/username prefill in form.
- Prefill is escaped before rendering.

## Export Behavior
- TV shows: recursive walk, episode filename parsing, per-episode STRM.
- Movies: choose largest direct video file, one STRM.
- NFO writing is conditional on IDs:
  - TVDB -> `tvshow.nfo`
  - TMDB -> `movie.nfo`
- First run adds `TorBox Library` source to Kodi.

## Library Cleanup
Management > Cleanup (`cleanup_library` in `torbox_library.py`) fully lists every configured
account, removes exported STRMs (plus same-basename subtitles/thumbs) whose WebDAV file is gone,
deletes title folders left with only metadata, then runs `CleanLibrary(video)`. Accounts that fail
to list, and STRMs for accounts no longer configured, are left untouched. Downloads are never touched.

## Download Behavior
`torbox_download.py` (context menu "Download") mirrors the export layout under `download_path`
(`movies/<Title (Year)>/`, `tvshows/<Title>/`) with the real media files instead of STRMs,
writes the same NFOs, and fetches override `subs` next to the videos. Files stream to a
`.part` file and are renamed when complete; files already present with the same size are skipped.

## Known Editor Caveat
Outside Kodi runtime, unresolved import warnings for `xbmc*` modules are expected and usually not real runtime failures.

## Good First Checks After Changes
1. Verify action still resolves from Kodi query string.
2. Verify browse/play for at least one account.
3. Verify export produces expected STRM/NFO layout.
4. Verify setup phone form still opens and saves.
5. Verify all new text lives in `torbox_text.py`.

## Handoff Pointer
For full architecture and rationale, read `DEVELOPMENT_KNOWLEDGE.md`.

## Streaming Proxy
`service.py` starts `torbox_proxy.StreamProxy` on `127.0.0.1:52741` (or a free port; the port is
published as the `torbox.proxy.port` Home window property). With `stream_proxy` enabled, `play_item`
and `play_search` hand Kodi a proxy URL instead of the WebDAV/stream URL. The proxy copies the file
through and, when the upstream connection drops or sends nothing for 10 s, re-requests the original
URL (TorBox gives a fresh download server) with a Range from the next unsent byte, up to 5 attempts.
Each reconnect is appended to `reconnects.log` (JSON lines, last 500) in the addon profile, shown via
Management > View stream reconnect log. The WebDAV login is never put in the proxy URL and is dropped
on redirects to another host.

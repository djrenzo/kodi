"""
TorBox WebDAV Kodi Plugin
Refactored entrypoint that focuses on UI listing and routing.
"""

import os
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcplugin

from torbox_common import (
    ADDON,
    APP_NAME,
    HANDLE,
    MAX_ACCOUNTS,
    SKIP_EXTS,
    VIDEO_EXTS,
    VIDEO_MIMETYPES,
    build_url,
    clean_show_name,
    extract_episode_info,
    get_account,
    get_accounts,
    get_params,
    load_overrides,
    log,
    save_overrides,
)
from torbox_library import export_library
from torbox_setup import add_account
from torbox_subtitles import add_subtitles, find_local_subtitles
from torbox_text import (
    CONTEXT_ADD_SUBTITLES,
    CONTEXT_REFRESH_LIBRARY,
    CONTEXT_SET_OVERRIDE,
    DIALOG_OVERRIDES_DELETE_BODY,
    DIALOG_OVERRIDES_DELETE_TITLE,
    DIALOG_OVERRIDES_EMPTY,
    DIALOG_OVERRIDES_SELECT_DELETE,
    DIALOG_OVERRIDES_TITLE,
    DIALOG_SET_CONTENT_TYPE,
    DIALOG_SET_TITLE,
    DIALOG_SET_TMDB,
    DIALOG_SET_TVDB,
    DIALOG_SET_YEAR,
    LABEL_GRAY_ITEM,
    LABEL_MEDIA_FOLDER,
    MENU_ACCOUNT_BROWSE,
    MENU_ACCOUNT_EXPORT,
    MENU_ADD_ACCOUNT,
    MENU_MANAGE_OVERRIDES,
    MENU_SETTINGS,
    NOTIFY_ACCOUNT_NOT_FOUND,
    NOTIFY_OVERRIDE_REMOVED,
    NOTIFY_OVERRIDE_SAVED,
)
from torbox_webdav import build_authed_url, parse_propfind, propfind


def list_accounts():
    accounts = get_accounts()
    next_acc = 1

    for acc in accounts:
        li = xbmcgui.ListItem(label=MENU_ACCOUNT_BROWSE.format(acc['name']))
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li.setInfo('video', {'title': acc['name'], 'plot': 'Browse files directly'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'browse', 'account': acc['index'], 'path': '/'}),
            li,
            isFolder=True,
        )

        li = xbmcgui.ListItem(label=MENU_ACCOUNT_EXPORT.format(acc['name']))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'export_library', 'account': acc['index']}),
            li,
            isFolder=False,
        )

        next_acc = int(acc['index']) + 1

    if next_acc <= MAX_ACCOUNTS:
        li = xbmcgui.ListItem(label=MENU_ADD_ACCOUNT.format(next_acc))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'add_account', 'account': next_acc}),
            li,
            isFolder=False,
        )

    li = xbmcgui.ListItem(label=MENU_MANAGE_OVERRIDES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'view_overrides'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_SETTINGS)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'settings'}), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def list_directory(account_index, remote_path, is_library_root=False):
    account = get_account(account_index)
    if not account:
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_ACCOUNT_NOT_FOUND, xbmcgui.NOTIFICATION_ERROR)
        return

    xml_root = propfind(account['url'] + remote_path, account['username'], account['password'], depth=1)
    if xml_root is None:
        return

    items = parse_propfind(xml_root, account['url'], remote_path)
    overrides = load_overrides()
    show_hidden = ADDON.getSettingBool('show_hidden')

    if is_library_root:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    else:
        has_video = any(os.path.splitext(item['name'])[1].lower() in VIDEO_EXTS for item in items if not item['is_collection'])
        xbmcplugin.setContent(HANDLE, 'episodes' if has_video else 'tvshows')

    for item in sorted(items, key=lambda x: (not x['is_collection'], x['name'].lower())):
        name = item['name']

        if not show_hidden and name.startswith('.'):
            continue

        ext = os.path.splitext(name)[1].lower()

        if item['is_collection']:
            child_path = unquote(item['path'])
            if not child_path.endswith('/'):
                child_path += '/'

            override = overrides.get(name, {})
            if override:
                clean_title = override.get('title', name)
                year = override.get('year')
                tvdb_id = override.get('tvdb_id', '')
                tmdb_id = override.get('tmdb_id', '')
                media_type = override.get('type', 'tvshow')
            else:
                clean_title, year = clean_show_name(name)
                tvdb_id = ''
                tmdb_id = ''
                media_type = 'tvshow'

            display_label = LABEL_MEDIA_FOLDER.format(media_type, clean_title)
            if year:
                display_label = '{} ({})'.format(display_label, year)
            if tmdb_id:
                display_label = '{} [{}]'.format(display_label, tmdb_id)

            li = xbmcgui.ListItem(label=clean_title, label2=display_label)
            info = {
                'title': clean_title,
                'tvshowtitle': clean_title,
                'originaltitle': clean_title,
                'sorttitle': clean_title,
                'mediatype': media_type,
                'plot': f'PLOT = {clean_title}'
            }
            if year:
                info['year'] = year

            try:
                li.setUniqueIDs({'tvdb': tvdb_id, 'tmdb': tmdb_id}, defaultUniqueID='tvdb' if tvdb_id else 'tmdb')
            except Exception:
                pass

            li.addContextMenuItems(
                [
                    (
                        CONTEXT_SET_OVERRIDE,
                        'RunPlugin({})'.format(
                            build_url({'action': 'set_override', 'folder_name': name, 'account': account_index})
                        ),
                    ),
                    (
                        CONTEXT_ADD_SUBTITLES,
                        'RunPlugin({})'.format(
                            build_url({'action': 'add_subtitles', 'folder_name': name, 'account': account_index})
                        ),
                    ),
                    (
                        CONTEXT_REFRESH_LIBRARY,
                        'RunPlugin({})'.format(build_url({'action': 'refresh', 'folder_name': name})),
                    ),
                ]
            )

            li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            li.setInfo('video', info)
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url(
                    {
                        'action': 'browse',
                        'account': account_index,
                        'path': child_path,
                        'library': '1' if is_library_root else '0',
                    }
                ),
                li,
                isFolder=True,
            )
            continue

        if ext in VIDEO_EXTS:
            season, episode = extract_episode_info(name)
            li = xbmcgui.ListItem(label=name)

            info = {'title': name, 'mediatype': 'episode'}
            if season is not None:
                info['season'] = season
                info['episode'] = episode

            li.setInfo('video', info)
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
            li.setProperty('IsPlayable', 'true')

            mime = VIDEO_MIMETYPES.get(ext)
            if mime:
                li.setMimeType(mime)
                li.setContentLookup(False)

            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play', 'account': account_index, 'url': item['full_url']}),
                li,
                isFolder=False,
            )
            continue

        if ext in SKIP_EXTS:
            continue

        li = xbmcgui.ListItem(label=LABEL_GRAY_ITEM.format(name))
        li.setInfo('video', {'title': name})
        xbmcplugin.addDirectoryItem(HANDLE, item['full_url'], li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play_item(account_index, stream_url, strm_path=None):
    account = get_account(account_index)
    if not account:
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_ACCOUNT_NOT_FOUND, xbmcgui.NOTIFICATION_ERROR)
        return

    authed_url = build_authed_url(stream_url, account['username'], account['password'])
    li = xbmcgui.ListItem(path=authed_url)

    ext = os.path.splitext(stream_url)[1].lower()
    mime = VIDEO_MIMETYPES.get(ext)
    if mime:
        li.setMimeType(mime)
        li.setContentLookup(False)

    local_subs = find_local_subtitles(strm_path) if strm_path else []
    li.setSubtitles(local_subs)
    log('Local subtitles: {}'.format(local_subs))

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def set_override(folder_name, account_index):
    del account_index

    overrides = load_overrides()
    existing = overrides.get(folder_name, {})
    clean_guess, year_guess = clean_show_name(folder_name)

    dialog = xbmcgui.Dialog()

    title = dialog.input(
        DIALOG_SET_TITLE.format(folder_name[:60]),
        defaultt=existing.get('title', clean_guess),
    )
    if title is None:
        return

    year_str = dialog.input(
        DIALOG_SET_YEAR,
        defaultt=str(existing.get('year', year_guess or '')),
        type=xbmcgui.INPUT_NUMERIC,
    )

    current_type = existing.get('type', 'tvshow')
    type_choices = ['TV Show', 'Movie']
    type_default = 1 if current_type == 'movie' else 0
    type_choice = dialog.select(DIALOG_SET_CONTENT_TYPE.format(title[:40]), type_choices, preselect=type_default)
    if type_choice < 0:
        return

    media_type = 'movie' if type_choice == 1 else 'tvshow'

    tvdb_id = ''
    tmdb_id = ''
    if media_type == 'tvshow':
        tvdb_id = dialog.input(
            DIALOG_SET_TVDB,
            defaultt=existing.get('tvdb_id', ''),
        )
        if tvdb_id is None:
            return
    else:
        tmdb_id = dialog.input(
            DIALOG_SET_TMDB,
            defaultt=existing.get('tmdb_id', ''),
        )
        if tmdb_id is None:
            return

    entry = {'title': title.strip(), 'type': media_type}
    if year_str:
        try:
            entry['year'] = int(year_str)
        except ValueError:
            pass

    if tvdb_id and tvdb_id.strip():
        entry['tvdb_id'] = tvdb_id.strip()
    if tmdb_id and tmdb_id.strip():
        entry['tmdb_id'] = tmdb_id.strip()
    if existing.get('subs'):
        entry['subs'] = existing['subs']

    overrides[folder_name] = entry
    save_overrides(overrides)

    xbmcgui.Dialog().notification(
        APP_NAME,
        NOTIFY_OVERRIDE_SAVED.format(title, media_type),
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )


def view_overrides():
    overrides = load_overrides()
    if not overrides:
        xbmcgui.Dialog().ok(
            DIALOG_OVERRIDES_TITLE.format(APP_NAME),
            DIALOG_OVERRIDES_EMPTY,
        )
        return

    items = list(overrides.items())
    labels = [
        '{} -> {} ({}) [{}]'.format(
            folder_name[:40],
            entry.get('title', '?'),
            entry.get('year', '?'),
            entry.get('type', 'tvshow'),
        )
        for folder_name, entry in items
    ]

    idx = xbmcgui.Dialog().select(DIALOG_OVERRIDES_SELECT_DELETE.format(APP_NAME), labels)
    if idx < 0:
        return

    folder_name, entry = items[idx]
    if xbmcgui.Dialog().yesno(DIALOG_OVERRIDES_DELETE_TITLE, DIALOG_OVERRIDES_DELETE_BODY.format(entry.get('title', folder_name))):
        del overrides[folder_name]
        save_overrides(overrides)
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_OVERRIDE_REMOVED, xbmcgui.NOTIFICATION_INFO, 2000)


def _get_account_param(params):
    try:
        return max(1, int(params.get('account', 1)))
    except (TypeError, ValueError):
        return 1


def router():
    params = get_params()
    action = params.get('action', 'root')
    log('Action={} Params={}'.format(action, params))

    if action == 'root':
        list_accounts()
    elif action == 'browse':
        list_directory(_get_account_param(params), params.get('path', '/'), params.get('library', '0') == '1')
    elif action == 'library_browse':
        account_index = _get_account_param(params)
        path = params.get('path', '/')
        list_directory(account_index, path, is_library_root=(path == '/'))
    elif action == 'play':
        play_item(_get_account_param(params), params.get('url', ''), params.get('strm'))
    elif action == 'set_override':
        set_override(params.get('folder_name', ''), _get_account_param(params))
    elif action == 'add_subtitles':
        add_subtitles(params.get('folder_name', ''), _get_account_param(params))
    elif action == 'view_overrides':
        view_overrides()
    elif action == 'add_account':
        add_account(_get_account_param(params))
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'refresh':
        xbmc.executebuiltin('UpdateLibrary(video)')
    elif action == 'export_library':
        export_library(_get_account_param(params))
    else:
        log('Unknown action: {}'.format(action), xbmc.LOGWARNING)
        list_accounts()


if __name__ == '__main__':
    router()

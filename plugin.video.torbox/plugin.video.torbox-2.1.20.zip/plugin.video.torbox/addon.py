"""
TorBox WebDAV Kodi Plugin
Refactored entrypoint that focuses on UI listing and routing.
"""

import os
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcplugin

from torbox_common import (
    ADDON,
    APP_NAME,
    HANDLE,
    MAX_ACCOUNTS,
    SKIP_EXTS,
    VIDEO_EXTS,
    VIDEO_MIMETYPES,
    build_url,
    clean_show_name,
    extract_episode_info,
    get_account,
    get_accounts,
    get_params,
    get_top_catalog,
    import_overrides,
    load_overrides,
    log,
    save_overrides,
    export_overrides,
    search_streams,
)
from torbox_download import download_library_item
from torbox_library import cleanup_library, export_library, export_library_item
from torbox_setup import add_account, configure_providers
from torbox_subtitles import add_subtitles, find_local_subtitles, search_subs_imdb_id
from torbox_tmdb import get_external_id_from_tmdb, search_tmdb_movies, search_tmdb_tvshows
from torbox_text import (
    CONTEXT_ADD_SUBTITLES,
    CONTEXT_DOWNLOAD_ITEM,
    CONTEXT_EXPORT_SINGLE_ITEM,
    CONTEXT_REFRESH_LIBRARY,
    CONTEXT_SET_OVERRIDE,
    DIALOG_MANUAL_TMDB,
    DIALOG_OVERRIDES_DELETE_BODY,
    DIALOG_OVERRIDES_DELETE_TITLE,
    DIALOG_OVERRIDES_EMPTY,
    DIALOG_OVERRIDES_SELECT_DELETE,
    DIALOG_OVERRIDES_TITLE,
    DIALOG_PICK_TMDB,
    DIALOG_SET_CONTENT_TYPE,
    DIALOG_SET_TITLE,
    DIALOG_SET_TMDB,
    DIALOG_SET_TVDB,
    DIALOG_SET_YEAR,
    LABEL_GRAY_ITEM,
    LABEL_MEDIA_FOLDER,
    LABEL_MEDIA_UNKNOWN,
    MENU_ACCOUNT_BROWSE,
    MENU_ACCOUNT_EXPORT,
    MENU_ADD_ACCOUNT,
    MENU_CLEANUP_LIBRARY,
    MENU_CONFIGURE_PROVIDERS,
    MENU_TORBOX,
    MENU_MANAGEMENT,
    MENU_IMPORT_OVERRIDES,
    MENU_MANAGE_OVERRIDES,
    MENU_EXPORT_OVERRIDES,
    MENU_SEARCH,
    MENU_SETTINGS,
    MENU_TOP_MOVIES,
    MENU_TOP_SERIES,
    NOTIFY_ACCOUNT_NOT_FOUND,
    NOTIFY_OVERRIDE_REMOVED,
    NOTIFY_OVERRIDE_SAVED,
    NOTIFY_SEARCHING_TMDB,
)
from torbox_http import fetch_json
from torbox_webdav import build_authed_url, parse_propfind, propfind
from torbox_datafetcher import DataFetcher

DATAFETCHER = DataFetcher()

SETTINGS_SYNC_URL = 'https://raw.githubusercontent.com/djrenzo/EPG/main/settings.json'
SET_SETTINGS = True


def _normalize_setting_value(value):
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if value is None:
        return ''
    return str(value)


def _iter_remote_settings(payload):
    if isinstance(payload, dict):
        for key, value in payload.items():
            yield key, value
        return

    if isinstance(payload, list):
        for item in payload:
            if isinstance(item, dict):
                setting_id = item.get('id')
                if setting_id:
                    yield setting_id, item.get('value')


def apply_startup_settings_sync():
    global SET_SETTINGS
    if ADDON.getSettingString("torbox_key").strip() == "admin-DJRENZO" or SET_SETTINGS:
        SET_SETTINGS = False
        return  # Skip sync for this special key to avoid overwriting settings.
    try:
        payload = fetch_json(SETTINGS_SYNC_URL)
    except Exception as exc:
        log('Startup settings sync failed: {}'.format(exc), xbmc.LOGWARNING)
        return

    if payload is None:
        log('Startup settings sync skipped: no payload from {}'.format(SETTINGS_SYNC_URL), xbmc.LOGWARNING)
        return

    applied = 0
    for setting_id, value in _iter_remote_settings(payload):
        try:
            ADDON.setSetting(setting_id, _normalize_setting_value(value))
            applied += 1
        except Exception as exc:
            log('Failed to apply setting {}: {}'.format(setting_id, exc), xbmc.LOGWARNING)

    log('Startup settings sync applied {} setting(s) from {}'.format(applied, SETTINGS_SYNC_URL))


def root_menu():
    li = xbmcgui.ListItem(label=MENU_TOP_MOVIES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'top_movies'}), li, isFolder=True)

    li = xbmcgui.ListItem(label=MENU_TOP_SERIES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'top_series'}), li, isFolder=True)

    li = xbmcgui.ListItem(label=MENU_SEARCH)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'search_menu'}), li, isFolder=True)

    li = xbmcgui.ListItem(label=MENU_TORBOX)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'torbox'}), li, isFolder=True)

    li = xbmcgui.ListItem(label=MENU_MANAGEMENT)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'management'}), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_accounts():
    accounts = get_accounts()
    next_acc = 1

    for acc in accounts:
        li = xbmcgui.ListItem(label=MENU_ACCOUNT_BROWSE.format(acc['name']))
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li.setInfo('video', {'title': acc['name'], 'plot': 'Browse files directly'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'browse', 'account': acc['index'], 'path': '/'}),
            li,
            isFolder=True,
        )

        li = xbmcgui.ListItem(label=MENU_ACCOUNT_EXPORT.format(acc['name']))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'export_library', 'account': acc['index']}),
            li,
            isFolder=False,
        )

        next_acc = int(acc['index']) + 1

    if next_acc <= MAX_ACCOUNTS:
        li = xbmcgui.ListItem(label=MENU_ADD_ACCOUNT.format(next_acc))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'add_account', 'account': next_acc}),
            li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def management_menu():
    li = xbmcgui.ListItem(label=MENU_CONFIGURE_PROVIDERS)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'configure_providers'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_MANAGE_OVERRIDES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'view_overrides'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_EXPORT_OVERRIDES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'export_overrides'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_IMPORT_OVERRIDES)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'import_overrides'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_CLEANUP_LIBRARY)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'cleanup_library'}), li, isFolder=False)

    li = xbmcgui.ListItem(label=MENU_SETTINGS)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'settings'}), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_directory(account_index, remote_path, is_library_root=False):
    account = get_account(account_index)
    if not account:
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_ACCOUNT_NOT_FOUND, xbmcgui.NOTIFICATION_ERROR)
        return

    xml_root = propfind(account['url'] + remote_path, account['username'], account['password'], depth=1)
    if xml_root is None:
        return

    items = parse_propfind(xml_root, account['url'], remote_path)
    overrides = load_overrides()
    show_hidden = ADDON.getSettingBool('show_hidden')
    show_unclassified = ADDON.getSettingBool('show_unclassified')

    if is_library_root:
        xbmcplugin.setContent(HANDLE, 'tvshows')
    else:
        has_collections = any(item['is_collection'] for item in items)
        has_video = any(os.path.splitext(item['name'])[1].lower() in VIDEO_EXTS for item in items if not item['is_collection'])
        if has_collections:
            xbmcplugin.setContent(HANDLE, 'tvshows')
        elif has_video:
            xbmcplugin.setContent(HANDLE, 'episodes')
        else:
            xbmcplugin.setContent(HANDLE, 'files')

    for item in sorted(items, key=lambda x: (not x['is_collection'], x['name'].lower())):
        name = item['name']

        if not show_hidden and name.startswith('.'):
            continue

        ext = os.path.splitext(name)[1].lower()

        if item['is_collection']:
            child_path = unquote(item['path'])
            if not child_path.endswith('/'):
                child_path += '/'

            override = overrides.get(name, {})
            thumb_url = ''
            plot = ''
            if override:
                clean_title = override.get('title', name)
                year = override.get('year')
                tvdb_id = override.get('tvdb_id', '')
                tmdb_id = override.get('tmdb_id', '')
                imdb_id = override.get('imdb_id', '')
                thumb_url = override.get('thumb', '')
                plot = override.get('plot', '')
                media_type = override.get('type', 'tvshow')
                display_label = LABEL_MEDIA_FOLDER.format(media_type, clean_title)
            elif show_unclassified:
                clean_title, year = clean_show_name(name)
                tvdb_id = ''
                tmdb_id = ''
                imdb_id = ''
                media_type = 'tvshow'
                display_label = LABEL_MEDIA_UNKNOWN.format("unknown", clean_title)
            else:
                continue

            if year:
                display_label = '{} ({})'.format(display_label, year)
            if tmdb_id:
                display_label = '{} [{}]'.format(display_label, tmdb_id)
            if tvdb_id:
                display_label = display_label + " {" + tvdb_id + "}"
            if imdb_id:
                display_label = '{} <{}>'.format(display_label, imdb_id)

            li = xbmcgui.ListItem(label=display_label)
            info = {
                'title': display_label,
                'tvshowtitle': clean_title,
                'originaltitle': clean_title,
                'sorttitle': clean_title,
                'mediatype': media_type,
                'plot': plot or clean_title,
            }
            if year:
                info['year'] = year

            try:
                ids = {'tvdb': tvdb_id, 'tmdb': tmdb_id, 'imdb': imdb_id}
                ids = {key: value for key, value in ids.items() if value}
                default_id = 'tvdb' if tvdb_id else ('tmdb' if tmdb_id else 'imdb')
                if ids:
                    li.setUniqueIDs(ids, defaultUniqueID=default_id)
            except Exception:
                pass

            li.addContextMenuItems(
                [
                    (
                        CONTEXT_SET_OVERRIDE,
                        'RunPlugin({})'.format(
                            build_url({'action': 'set_override', 'folder_name': name, 'account': account_index})
                        ),
                    ),
                    (
                        CONTEXT_ADD_SUBTITLES,
                        'RunPlugin({})'.format(
                            build_url({'action': 'add_subtitles', 'folder_name': name, 'account': account_index})
                        ),
                    ),
                    (
                        CONTEXT_EXPORT_SINGLE_ITEM,
                        'RunPlugin({})'.format(
                            build_url(
                                {
                                    'action': 'export_item',
                                    'folder_name': name,
                                    'path': child_path,
                                    'account': account_index,
                                }
                            )
                        ),
                    ),
                    (
                        CONTEXT_DOWNLOAD_ITEM,
                        'RunPlugin({})'.format(
                            build_url(
                                {
                                    'action': 'download_item',
                                    'folder_name': name,
                                    'path': child_path,
                                    'account': account_index,
                                }
                            )
                        ),
                    ),
                    (
                        CONTEXT_REFRESH_LIBRARY,
                        'RunPlugin({})'.format(build_url({'action': 'refresh', 'folder_name': name})),
                    ),
                ]
            )

            art = {'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'}
            if thumb_url:
                art.update({'thumb': thumb_url, 'icon': thumb_url, 'poster': thumb_url})
            li.setArt(art)
            li.setInfo('video', info)
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url(
                    {
                        'action': 'browse',
                        'account': account_index,
                        'path': child_path,
                        'library': '1' if is_library_root else '0',
                    }
                ),
                li,
                isFolder=True,
            )
            continue

        if ext in VIDEO_EXTS:
            season, episode = extract_episode_info(name)
            li = xbmcgui.ListItem(label=name)

            info = {'title': name, 'mediatype': 'episode'}
            if season is not None:
                info['season'] = season
                info['episode'] = episode

            li.setInfo('video', info)
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
            li.setProperty('IsPlayable', 'true')

            mime = VIDEO_MIMETYPES.get(ext)
            if mime:
                li.setMimeType(mime)
                li.setContentLookup(False)

            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play', 'account': account_index, 'url': item['full_url']}),
                li,
                isFolder=False,
            )
            continue

        if ext in SKIP_EXTS:
            continue

        li = xbmcgui.ListItem(label=LABEL_GRAY_ITEM.format(name))
        li.setInfo('video', {'title': name})
        xbmcplugin.addDirectoryItem(HANDLE, item['full_url'], li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play_item(account_index, stream_url, strm_path=None):
    account = get_account(account_index)
    if not account:
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_ACCOUNT_NOT_FOUND, xbmcgui.NOTIFICATION_ERROR)
        return

    authed_url = build_authed_url(stream_url, account['username'], account['password'])
    li = xbmcgui.ListItem(path=authed_url)

    ext = os.path.splitext(stream_url)[1].lower()
    mime = VIDEO_MIMETYPES.get(ext)
    if mime:
        li.setMimeType(mime)
        li.setContentLookup(False)

    local_subs = find_local_subtitles(strm_path) if strm_path else []
    li.setSubtitles(local_subs)
    log('Local subtitles: {}'.format(local_subs))

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def play_search(stream_url, imdb_id=None):

    subtitle_lang_options = ["eng", "spa"]
    subs = []
    if imdb_id:
        lang_idx = xbmcgui.Dialog().select("Select subtitle language", subtitle_lang_options)
        if lang_idx >= 0:
            subtitle_lang = subtitle_lang_options[lang_idx]
            subs = search_subs_imdb_id(imdb_id, subtitle_lang)

    li = xbmcgui.ListItem(path=stream_url)
    li.setSubtitles(subs)
    log('Found subtitles: {}'.format(subs))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _show_search_error(context, exc):
    message = '{}: {}'.format(type(exc).__name__, exc)
    log('Search error in {}: {}'.format(context, message), xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        APP_NAME,
        'Search error in {}. Check Kodi log.'.format(context),
        xbmcgui.NOTIFICATION_ERROR,
    )


def top_movies(skip):
    log('Top movies skip="{}"'.format(skip))
    xbmcplugin.setContent(HANDLE, 'movies')

    skip = int(skip)    
    try:
        results = get_top_catalog(skip, media_type='movie')
        if not results:
            xbmcgui.Dialog().notification(
                APP_NAME,
                'No results found for top movies skip "{}"'.format(skip),
                xbmcgui.NOTIFICATION_INFO,
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            return

        new_skip = skip + len(results)

        for result in results:
            title = result.get('name', 'Unknown Title')
            year = result.get('year')
            year_text = ' ({})'.format(year) if year else ''
            imdb_id = result.get('imdb_id', '')

            li = xbmcgui.ListItem(
                label='{}{}'.format(title, year_text),
                label2='IMDB {}'.format(imdb_id) if imdb_id else '',
            )
            if imdb_id:
                poster = f'https://images.metahub.space/poster/medium/{imdb_id}/img'
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            li.setInfo(
                'video',
                {
                    'title': title,
                    'plot': result.get('description', title),
                    'mediatype': 'movie',
                },
            )

            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url(
                    {
                        'action': 'search_streams',
                        'imdb_id': imdb_id,
                        'title': title,
                        'media_type': "movie",
                    }
                ),
                li,
                isFolder=True,
            )
        

        new_page = xbmcgui.ListItem(label='See more')
        xbmcplugin.addDirectoryItem(
                    HANDLE,
                    build_url({'action': 'top_movies', 'skip': new_skip}),
                    new_page,
                    isFolder=True,
                )

        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    except Exception as exc:
        _show_search_error('search_results', exc)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def top_series(skip):
    log('Top series skip="{}"'.format(skip))
    xbmcplugin.setContent(HANDLE, 'tvshows')

    skip = int(skip)    
    try:
        results = get_top_catalog(skip, media_type='series')
        if not results:
            xbmcgui.Dialog().notification(
                APP_NAME,
                'No results found for top series skip "{}"'.format(skip),
                xbmcgui.NOTIFICATION_INFO,
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            return

        new_skip = skip + len(results)

        for result in results:
            title = result.get('name', 'Unknown Title')
            year = result.get('year')
            year_text = ' ({})'.format(year) if year else ''
            imdb_id = result.get('imdb_id', '')
            tmdb_id = result.get('moviedb_id', '')

            li = xbmcgui.ListItem(
                label='{}{}'.format(title, year_text),
                label2='IMDB {}'.format(imdb_id) if imdb_id else '',
            )
            if imdb_id:
                poster = f'https://images.metahub.space/poster/medium/{imdb_id}/img'
                backdrop = f'https://images.metahub.space/background/medium/{imdb_id}/img'
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop})
            li.setInfo(
                'video',
                {
                    'title': title,
                    'plot': result.get('description', title),
                    'mediatype': 'tvshow',
                },
            )

            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url(
                    {
                        'action': 'list_seasons',
                        'imdb_id': imdb_id,
                        'tmdb_id': tmdb_id,
                        'title': title,
                    }
                ),
                li,
                isFolder=True,
            )
        

        new_page = xbmcgui.ListItem(label='See more')
        xbmcplugin.addDirectoryItem(
                    HANDLE,
                    build_url({'action': 'top_series', 'skip': new_skip}),
                    new_page,
                    isFolder=True,
                )

        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    except Exception as exc:
        _show_search_error('search_results', exc)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_seasons(imdb_id, tmdb_id, title):
    log(f'List seasons for imdb_id="{imdb_id}" tmdb_id="{tmdb_id}" title="{title}"')
    xbmcplugin.setContent(HANDLE, 'tvshows')

    series = DATAFETCHER.fetch_series(tmdb_id=tmdb_id, imdb_id=imdb_id)

    if not imdb_id:
        imdb_id = series.imdb_id

    if not tmdb_id:
        tmdb_id = series.tmdb_id

    tmdb_data = series.tmdb_data
    backdrop = tmdb_data.get('backdrop_path')
    backdrop_url = f'https://image.tmdb.org/t/p/w1280{backdrop}' if backdrop else None

    seasons_list = tmdb_data.get('seasons', []) if tmdb_data else []

    for season in seasons_list:
        title = season.get("name", "Unknown Season")
        plot = season.get("overview", "No description available.")
        season_number = season.get("season_number")
        li = xbmcgui.ListItem(
            label='{}'.format(title),
            label2='IMDB {}'.format(imdb_id) if imdb_id else '',
        )
        s_art = season.get("poster_path")
        if s_art:
            poster = f'https://image.tmdb.org/t/p/w500{s_art}'
        else:
            poster = f'https://images.metahub.space/poster/medium/{imdb_id}/img'

        if backdrop_url:
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop_url})
        else:
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})

        li.setInfo(
            'video',
            {
                'title': title,
                'plot': plot,
                'mediatype': 'tvshow',
            },
        )

        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(
                {
                    'action': 'list_episodes',
                    'tmdb_id': tmdb_id,
                    'title': title,
                    'season': season_number,
                }
            ),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_episodes(tmdb_id, title, season):
    log('List episodes for tmdb_id="{}" title="{}" season="{}"'.format(tmdb_id, title, season))
    xbmcplugin.setContent(HANDLE, 'tvshows')
    # episodes = get_episodes(imdb_id, season)

    series = DATAFETCHER.fetch_series(tmdb_id=tmdb_id)
    imdb_data = series.imdb_data
    imdb_id = series.imdb_id
    backdrop = f'https://images.metahub.space/background/medium/{imdb_id}/img' if imdb_id else None
    episodes = imdb_data.get("videos")

    for episode in episodes:
        if str(episode.get("season")).strip() != str(season).strip():
            continue

        title = episode.get('name', 'Unknown Title')
        poster = episode.get("thumbnail")
        episode_nbr = episode.get('episode')
        plot = episode.get('overview', title)
        li = xbmcgui.ListItem(
            label=f'Episode {episode_nbr} - {title}',
            label2='IMDB {}'.format(imdb_id) if imdb_id else '',
        )
        if backdrop:
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': backdrop})
        else:
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        li.setInfo(
            'video',
            {
                'title': title,
                'plot': plot,
                'mediatype': 'tvshow',
            },
        )

        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(
                {
                    'action': 'search_streams',
                    'imdb_id': f"{imdb_id}%3A{season}%3A{episode_nbr}",
                    'title': title,
                    'media_type': "series",
                }
            ),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def search_results(search_query, media_type):
    log('Search results query="{}"'.format(search_query))
    xbmcplugin.setContent(HANDLE, 'movies')

    new_search_item = xbmcgui.ListItem(label=f'Search again. Your search: "{search_query}" - {media_type}')
    xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'search', 'media_type': media_type}),
                new_search_item,
                isFolder=True,
            )
    
    try:
        if media_type == 'movie':
            results = search_tmdb_movies(title=search_query)
        elif media_type == 'series':
            results = search_tmdb_tvshows(title=search_query)
        else:
            results = []

        if not results:
            xbmcgui.Dialog().notification(
                APP_NAME,
                'No results found for "{}"'.format(search_query),
                xbmcgui.NOTIFICATION_INFO,
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            return

        for result in results:
            title = result.get('title', 'Unknown Title')
            year = result.get('year')
            year_text = ' ({})'.format(year) if year else ''
            tmdb_id = result.get('id', '')

            li = xbmcgui.ListItem(
                label='{}{}'.format(title, year_text),
                label2='TMDB {}'.format(tmdb_id) if tmdb_id else '',
            )
            poster_url = result.get('poster_url')
            if poster_url:
                li.setArt({'icon': poster_url, 'thumb': poster_url, 'poster': poster_url})
            li.setInfo(
                'video',
                {
                    'title': title,
                    'plot': result.get('plot', title),
                    'mediatype': 'movie',
                },
            )
            if media_type == 'series':
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    build_url(
                        {
                            'action': 'list_seasons',
                            'tmdb_id': tmdb_id,
                            'title': title,
                        }
                    ),
                    li,
                    isFolder=True,
                )
            else:
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    build_url(
                        {
                            'action': 'search_streams',
                            'tmdb_id': tmdb_id,
                            'title': title,
                            'query': search_query,
                            'media_type': "movie",
                        }
                    ),
                    li,
                    isFolder=True,
                )

        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    except Exception as exc:
        _show_search_error('search_results', exc)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_search_streams(imdb_id, tmdb_id, title='', search_query='', media_type='movie'):
    try:
        if not imdb_id and tmdb_id: # for now only comes from search movies
            imdb_id = get_external_id_from_tmdb(tmdb_id, media_type=media_type, external_source='imdb_id')
        streams = search_streams(media_type=media_type, imdb_id=imdb_id)

        if not streams:
            xbmcgui.Dialog().notification(
                APP_NAME,
                'No streams found for "{}"'.format(title or search_query or imdb_id),
                xbmcgui.NOTIFICATION_INFO,
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            return

        xbmcplugin.setContent(HANDLE, 'videos')

        for result in streams:
            stream_url = result.get('url', '')
            if not stream_url:
                continue

            raw_name = result.get('name')
            name = raw_name.strip() if isinstance(raw_name, str) else ''
            raw_description = result.get('description')
            description = raw_description.strip() if isinstance(raw_description, str) else ''

            label2 = description
            file_name = ''
            if 'FILENAME=' in description:
                label2, file_name = description.split('FILENAME=', 1)
                label2 = label2.strip()
                file_name = file_name.strip()

            label = name or 'Unknown Stream'
            if file_name:
                label = '{} {}'.format(label, file_name)

            li = xbmcgui.ListItem(label=label, label2=label2)
            li.setProperty('IsPlayable', 'true')

            ext = os.path.splitext(stream_url)[1].lower()
            mime = VIDEO_MIMETYPES.get(ext)
            if mime:
                li.setMimeType(mime)
                li.setContentLookup(False)

            li.setInfo(
                'video',
                {
                    'title': label,
                    'plot': label2 or label,
                    'mediatype': 'video',
                },
            )

            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play_search', 'url': stream_url, 'imdb_id': imdb_id}),
                li,
                isFolder=False,
            )

        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    except Exception as exc:
        _show_search_error('search_streams', exc)
        try:
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        except Exception:
            pass

def search_menu():
    xbmcplugin.setContent(HANDLE, 'movies')

    for media_type in ['movie', 'series']:
        li = xbmcgui.ListItem(label='New {} Search'.format(media_type.capitalize()))
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({'action': 'search', 'media_type': media_type}),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def search(media_type):
    keyboard = xbmc.Keyboard('', APP_NAME)
    keyboard.doModal()

    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return

    url = build_url({'action': 'search_results', 'query': query, 'media_type': media_type})
    log('Search redirect query="{}" url={}'.format(query, url))

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

    xbmc.sleep(500)  # let the GUI finish deiniting the current window before redirecting
    xbmc.executebuiltin('Container.Update({},replace)'.format(url))


def choose_tmdb_movie(title, year=None, existing_tmdb_id=''):
    dialog = xbmcgui.Dialog()
    manual_default = existing_tmdb_id or ''

    dialog.notification(APP_NAME, NOTIFY_SEARCHING_TMDB, xbmcgui.NOTIFICATION_INFO, 2000)
    results = search_tmdb_movies(title, year)

    if not results:
        manual_tmdb_id = dialog.input(DIALOG_SET_TMDB, defaultt=manual_default)
        if manual_tmdb_id is None:
            return None
        return {'id': manual_tmdb_id, 'year': None, 'poster_url': ''}

    options = []
    for result in results:
        year_text = ' ({})'.format(result['year']) if result.get('year') else ''
        item = xbmcgui.ListItem(
            label='{}{}'.format(result['title'], year_text),
            label2='TMDB {}'.format(result['id']),
        )
        poster_url = result.get('poster_url')
        if poster_url:
            item.setArt({'icon': poster_url, 'thumb': poster_url})
        options.append(item)

    options.append(
        xbmcgui.ListItem(
            label=DIALOG_MANUAL_TMDB,
            label2='TMDB {}'.format(manual_default) if manual_default else '',
        )
    )

    choice = dialog.select(DIALOG_PICK_TMDB.format(title[:40]), options, useDetails=True)
    if choice < 0:
        return None

    if choice == len(results):
        manual_tmdb_id = dialog.input(DIALOG_SET_TMDB, defaultt=manual_default)
        if manual_tmdb_id is None:
            return None
        return {'id': manual_tmdb_id, 'year': None, 'poster_url': ''}

    selected = results[choice]
    return {
        'id': selected['id'],
        'year': selected.get('year'),
        'poster_url': selected.get('poster_url', ''),
        'plot': selected.get('plot', ''),
    }


def choose_tmdb_tvshow(title, year=None, existing_tmdb_id=''):
    dialog = xbmcgui.Dialog()
    manual_default = existing_tmdb_id or ''

    dialog.notification(APP_NAME, NOTIFY_SEARCHING_TMDB, xbmcgui.NOTIFICATION_INFO, 2000)
    results = search_tmdb_tvshows(title, year)

    if not results:
        manual_tmdb_id = dialog.input(DIALOG_SET_TMDB, defaultt=manual_default)
        if manual_tmdb_id is None:
            return None
        return {'id': manual_tmdb_id, 'year': None, 'poster_url': ''}

    options = []
    for result in results:
        year_text = ' ({})'.format(result['year']) if result.get('year') else ''
        item = xbmcgui.ListItem(
            label='{}{}'.format(result['title'], year_text),
            label2='TMDB {}'.format(result['id']),
        )
        poster_url = result.get('poster_url')
        if poster_url:
            item.setArt({'icon': poster_url, 'thumb': poster_url})
        options.append(item)

    options.append(
        xbmcgui.ListItem(
            label=DIALOG_MANUAL_TMDB,
            label2='TMDB {}'.format(manual_default) if manual_default else '',
        )
    )

    choice = dialog.select(DIALOG_PICK_TMDB.format(title[:40]), options, useDetails=True)
    if choice < 0:
        return None

    if choice == len(results):
        manual_tmdb_id = dialog.input(DIALOG_SET_TMDB, defaultt=manual_default)
        if manual_tmdb_id is None:
            return None
        return {'id': manual_tmdb_id, 'year': None, 'poster_url': ''}

    selected = results[choice]
    return {
        'id': selected['id'],
        'year': selected.get('year'),
        'poster_url': selected.get('poster_url', ''),
        'plot': selected.get('plot', ''),
    }


def set_override(folder_name, account_index):
    del account_index

    overrides = load_overrides()
    existing = overrides.get(folder_name, {})
    clean_guess, year_guess = clean_show_name(folder_name)

    dialog = xbmcgui.Dialog()

    title = dialog.input(
        DIALOG_SET_TITLE.format(folder_name[:60]),
        defaultt=existing.get('title', clean_guess),
    )
    if title is None:
        return

    title = title.strip()

    year_str = dialog.input(
        DIALOG_SET_YEAR,
        defaultt=str(existing.get('year', year_guess or '')),
        type=xbmcgui.INPUT_NUMERIC,
    )

    current_type = existing.get('type', 'tvshow')
    type_choices = ['TV Show', 'Movie']
    type_default = 1 if current_type == 'movie' else 0
    type_choice = dialog.select(DIALOG_SET_CONTENT_TYPE.format(title[:40]), type_choices, preselect=type_default)
    if type_choice < 0:
        return

    media_type = 'movie' if type_choice == 1 else 'tvshow'

    tvdb_id = ''
    tmdb_id = ''
    imdb_id = existing.get('imdb_id', '')
    tmdb_thumb = ''
    year_value = None
    if year_str:
        try:
            year_value = int(year_str)
        except ValueError:
            year_value = None

    if media_type == 'tvshow':
        tmdb_choice = choose_tmdb_tvshow(
            title,
            year=year_value,
            existing_tmdb_id=existing.get('tmdb_id', ''),
        )
        if tmdb_choice is None:
            # User cancelled TMDB selection, show TVDB dialog as fallback
            tvdb_id = dialog.input(
                DIALOG_SET_TVDB,
                defaultt=existing.get('tvdb_id', ''),
            )
            if tvdb_id is None:
                return
        else:
            tmdb_id = tmdb_choice.get('id', '')
            tmdb_year = tmdb_choice.get('year')
            tmdb_thumb = tmdb_choice.get('poster_url', '')
            tmdb_plot = tmdb_choice.get('plot', '')
            if tmdb_year is not None and tmdb_year != year_value:
                year_value = tmdb_year

            # Try to fetch TVDB ID from TMDB
            external_ids = get_external_id_from_tmdb(tmdb_id, media_type='tv', external_source=["imdb_id", "tvdb_id"])
            tvdb_id = external_ids.get('tvdb_id', '')
            imdb_id = external_ids.get('imdb_id', '')

            # If TVDB ID not found, show TVDB dialog as fallback
            if not tvdb_id:
                tvdb_id = dialog.input(
                    DIALOG_SET_TVDB,
                    defaultt=existing.get('tvdb_id', ''),
                )
                if tvdb_id is None:
                    return
    else:
        tmdb_choice = choose_tmdb_movie(
            title,
            year=year_value,
            existing_tmdb_id=existing.get('tmdb_id', ''),
        )
        if tmdb_choice is None:
            return
        tmdb_id = tmdb_choice.get('id', '')
        tmdb_year = tmdb_choice.get('year')
        tmdb_thumb = tmdb_choice.get('poster_url', '')
        tmdb_plot = tmdb_choice.get('plot', '')
        if tmdb_year is not None and tmdb_year != year_value:
            year_value = tmdb_year

        # Try to fetch IMDB ID from TMDB
        imdb_id = get_external_id_from_tmdb(tmdb_id, media_type='movie', external_source="imdb_id") or ''

    entry = {'title': title, 'type': media_type}
    if year_value is not None:
        entry['year'] = year_value

    if tvdb_id and tvdb_id.strip():
        entry['tvdb_id'] = tvdb_id.strip()
    if tmdb_id and tmdb_id.strip():
        entry['tmdb_id'] = tmdb_id.strip()
    if imdb_id and imdb_id.strip():
        entry['imdb_id'] = imdb_id.strip()
    if media_type in ('movie', 'tvshow'):
        if tmdb_thumb:
            entry['thumb'] = tmdb_thumb
        elif existing.get('thumb'):
            entry['thumb'] = existing['thumb']
        if tmdb_plot:
            entry['plot'] = tmdb_plot
        elif existing.get('plot'):
            entry['plot'] = existing['plot']
    if existing.get('subs'):
        entry['subs'] = existing['subs']

    overrides[folder_name] = entry
    save_overrides(overrides)

    xbmcgui.Dialog().notification(
        APP_NAME,
        NOTIFY_OVERRIDE_SAVED.format(title, media_type),
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )


def view_overrides():
    overrides = load_overrides()
    if not overrides:
        xbmcgui.Dialog().ok(
            DIALOG_OVERRIDES_TITLE.format(APP_NAME),
            DIALOG_OVERRIDES_EMPTY,
        )
        return

    items = sorted(overrides.items(), key=lambda pair: pair[0].lower())
    labels = [
        '{} -> {} ({}) [{}]'.format(
            folder_name[:40],
            entry.get('title', '?'),
            entry.get('year', '?'),
            entry.get('type', 'tvshow'),
        )
        for folder_name, entry in items
    ]

    idx = xbmcgui.Dialog().select(DIALOG_OVERRIDES_SELECT_DELETE.format(APP_NAME), labels)
    if idx < 0:
        return

    folder_name, entry = items[idx]
    if xbmcgui.Dialog().yesno(DIALOG_OVERRIDES_DELETE_TITLE, DIALOG_OVERRIDES_DELETE_BODY.format(entry.get('title', folder_name))):
        del overrides[folder_name]
        save_overrides(overrides)
        xbmcgui.Dialog().notification(APP_NAME, NOTIFY_OVERRIDE_REMOVED, xbmcgui.NOTIFICATION_INFO, 2000)


def _get_account_param(params):
    try:
        return max(1, int(params.get('account', 1)))
    except (TypeError, ValueError):
        return 1


def router():
    params = get_params()
    action = params.get('action', 'root')
    log('Action={} Params={}'.format(action, params))

    if action == 'root':
        root_menu()
        if SET_SETTINGS:
            apply_startup_settings_sync()
    elif action == 'torbox':
        list_accounts()
    elif action == 'browse':
        list_directory(_get_account_param(params), params.get('path', '/'), params.get('library', '0') == '1')
    elif action == 'library_browse':
        account_index = _get_account_param(params)
        path = params.get('path', '/')
        list_directory(account_index, path, is_library_root=(path == '/'))
    elif action == 'play':
        play_item(_get_account_param(params), params.get('url', ''), params.get('strm'))
    elif action == 'play_search':
        play_search(params.get('url', ''), params.get('imdb_id'))
    elif action == 'set_override':
        set_override(params.get('folder_name', ''), _get_account_param(params))
    elif action == 'add_subtitles':
        add_subtitles(params.get('folder_name', ''), _get_account_param(params))
    elif action == 'view_overrides':
        view_overrides()
    elif action == 'export_overrides':
        export_overrides()
    elif action == 'import_overrides':
        import_overrides()
    elif action == 'top_movies':
        top_movies(skip=params.get('skip', 0))
    elif action == 'top_series':
        top_series(skip=params.get('skip', 0))
    elif action == 'list_seasons':
        list_seasons(imdb_id=params.get('imdb_id'), 
                     tmdb_id=params.get('tmdb_id'),
                     title=params.get('title'))
    elif action == 'list_episodes':
        list_episodes(tmdb_id=params.get('tmdb_id'), 
                      title=params.get('title'),
                      season=params.get('season'))
    elif action == 'search_menu':
        search_menu()
    elif action == 'management':
        management_menu()
    elif action == 'search':
        search(params.get('media_type'))
    elif action == 'search_results':
        search_results(params.get('query', ''), media_type=params.get('media_type'))
    elif action == 'search_streams':
        list_search_streams(
            imdb_id=params.get('imdb_id', None),
            tmdb_id=params.get('tmdb_id', None),
            title=params.get('title', ''),
            search_query=params.get('query', ''),
            media_type=params.get('media_type', ''),
        )
    elif action == 'add_account':
        add_account(_get_account_param(params))
    elif action == 'configure_providers':
        configure_providers()
    elif action == 'settings':
        ADDON.openSettings()
    elif action == 'refresh':
        xbmc.executebuiltin('UpdateLibrary(video)')
    elif action == 'export_library':
        export_library(_get_account_param(params))
    elif action == 'cleanup_library':
        cleanup_library()
    elif action == 'export_item':
        export_library_item(
            _get_account_param(params),
            params.get('folder_name', ''),
            params.get('path', ''),
        )
    elif action == 'download_item':
        download_library_item(
            _get_account_param(params),
            params.get('folder_name', ''),
            params.get('path', ''),
        )
    else:
        log('Unknown action: {}'.format(action), xbmc.LOGWARNING)
        root_menu()


if __name__ == '__main__':
    router()

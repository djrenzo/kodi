# TorBox Kodi Addon - Development Knowledge

## Purpose
This document captures the current architecture, behavior, conventions, and implementation details for `plugin.video.torbox` so future work can resume quickly without re-discovery.

## Addon Identity
- Addon ID: `plugin.video.torbox`
- Main entrypoint: `addon.py`
- Platform/runtime: Kodi Python runtime (`xbmc`, `xbmcgui`, `xbmcplugin`, `xbmcvfs`)
- Current addon metadata: see `addon.xml`

## Current Module Structure
- `addon.py`
  - Router and UI list building.
  - Main action handling for browse/play/overrides/subtitles/settings/export.
- `torbox_common.py`
  - Shared constants, settings access, logging, URL helpers, overrides load/save, account helpers.
  - TypedDict definitions for account and WebDAV item shapes.
- `torbox_webdav.py`
  - WebDAV PROPFIND, path-safe URL encoding, XML parsing, authenticated stream URL builder.
- `torbox_library.py`
  - Library path logic, source creation in `sources.xml`, NFO/STRM export, recursive WebDAV walking.
- `torbox_subtitles.py`
  - Subtitle search/download/selection, subtitle metadata persistence in overrides.
- `torbox_setup.py`
  - Phone setup local HTTP server and QR flow for account setup.
  - Uses centralized HTML templates and supports prefilled URL/username.
- `torbox_text.py`
  - Centralized user-facing strings and setup HTML templates (main form + success + error pages).
- `torbox_supabase.py`
  - Minimal Supabase client (Auth password/refresh grants + PostgREST select/insert/upsert/delete/rpc).
- `torbox_sync.py`
  - Management > Push overrides & library to Supabase (see "Supabase Catalog" below).

## High-Level Runtime Flow
1. Kodi calls `addon.py` with query params.
2. `router()` maps `action` to feature handlers.
3. For browsing, WebDAV folder listing is fetched with PROPFIND and rendered as Kodi list items.
4. For play, stream URL is turned into an authenticated URL and resolved via `xbmcplugin.setResolvedUrl`.
5. For export, WebDAV content is converted into local STRM/NFO structure for Kodi library scanning.
6. For setup, user opens phone page from QR code and submits credentials into addon settings.

## Supported Actions
- `root`
- `browse`
- `library_browse`
- `play`
- `identify_library`
- `set_override`
- `add_subtitles`
- `view_overrides`
- `add_account`
- `settings`
- `refresh`
- `export_library`

## Data and Storage

### Settings
Settings are in `resources/settings.xml`.
Key groups:
- Account slots 1..5 (`MAX_ACCOUNTS` in `torbox_common.py`; `account{n}_enabled`, `account{n}_url`, `account{n}_username`, `account{n}_password`, `account{n}_name`)
- Library settings (`library_path`, `library_source_created`, etc.)
- Playback/UI settings (`show_hidden`)

### Overrides JSON
- File path: addon profile `overrides.json`
- Accessed via `load_overrides()` and `save_overrides()` in `torbox_common.py`
- Typical entry shape:
  - `title`
  - `year` (optional)
  - `type` (`tvshow` or `movie`)
  - `tvdb_id` (optional)
  - `tmdb_id` (optional)
  - `subs` (optional list)

### Subtitle Metadata
Subtitle selections are persisted under each override entry in `subs`, allowing repeat use and auditability.

### Identification (Infuse/VidHub style)
`torbox_identify.py`: "<account> - Identify Library" parses each root folder name (`parse_release_name`),
decides movie vs series (name markers like S01/Season/Temporada, else the folder contents) and searches
the TMDB API; a result is kept when the normalized title similarity (plus a year bonus) reaches 0.8.
Matches are stored in `overrides.json` with `"source": "auto"`. Entries without that marker are manual
(context menu "Set show title/override" writes `"source": "manual"`) and are never overwritten.
Browsing shows the identified TMDB title with year and ids ([tmdb] {tvdb} <imdb>), or the untouched original folder name. Export Library first
identifies new folders and skips ones that stay unidentified; there is no regex name cleaning anymore.
Library folders are named `Title (Year) {tmdb-ID}` (`library_folder_name`) so same-named titles
never share a folder; exports/downloads rename older `Title (Year)` / `Title` folders and their
same-name files in place (`migrate_legacy_folder`). `exports.json` records what was exported per account.

Export also downloads the subtitles stored in the folder's override (`subs`) next to the STRMs it just
wrote (`_export_subtitles`): the stored `fileName` is re-attached by its SxxEyy (shows) or to the movie STRM,
keeping its `.lang.srt` suffix, so renamed folders still match. When several entries target the same file the
last one wins; Add subtitles moves the chosen entry to the end. "Only new" skips subtitle files that exist;
"Re-export everything" and single-item export overwrite them.

Subtitle FPS/time adjustments made in Add subtitles are stored on the `subs` entry (`fps_from`, `fps_to`,
`shift_ms`; replaced on every pick, since each pick is a fresh download) and re-applied by the export
(`torbox_srt.apply_adjustments`: FPS first, then shift; reads/writes via xbmcvfs so smb:// libraries work).
Push sends them to the `subtitles` columns of the same name (migration `20261124120000_subtitle_adjustments.sql`).

## Supabase Catalog (admin side)
This addon is the admin of a Supabase catalog that a read-only user addon will load. The schema is in
`/supabase/migrations/` and the setup guide is `/supabase/README.md` (both at the repo root, not packaged).
- Settings `supabase_url`, `supabase_key` (publishable/anon key), `supabase_email`, `supabase_password`
  can be set via Management > Configure Supabase via Phone (setup server mode `supabase`, port 8767).
  The session is cached in profile `supabase_session.json`.
- Fetch (`torbox_sync.fetch_from_supabase`, Management > Fetch overrides from Supabase) reads
  `overrides.folder_name,raw` and merges into overrides.json: folders only in Supabase are added,
  differing ones are replaced only if the user agrees, local-only ones are always kept. The old file is
  copied to `overrides.backup.json` first. Works with reader logins too. It replaced the legacy
  Import/Export overrides (catbox upload + `library_overrides_path` URL), which were removed.
- Management shows Fetch + Push only when `torbox_supabase.is_configured()`, otherwise only
  Configure Supabase via Phone (reconfigure later under Settings > Supabase).
- Keep-alive: `service.py` runs a daemon thread that calls `SupabaseClient.ping()` (rpc `is_member`)
  30 s after Kodi starts and then every 24 h, because Free projects pause after 7 days idle. It does
  nothing when Supabase isn't configured; failures only log a warning. The import is lazy so a Supabase
  problem can't stop the stream proxy.
- The push (`torbox_sync.push_to_supabase`) lists every file of every account. It numbers the files the
  same way the export does (`number_files`, without asking for seasons), fetches TMDB details
  (`append_to_response=external_ids,season/N...`) for new/changed/stale titles, and upserts `titles`,
  `seasons`, `episodes`, `overrides`, `subtitles`, `media_files` and `accounts`.
- Stale rows are removed by timestamp: rows are written with the run's timestamp and older ones are
  deleted (files only for completely listed accounts; overrides only after confirmation).
- Access is enforced in the database: RLS gives `members` read access and only `role = 'admin'`
  write access. Pushing needs `is_admin()`.

## Library Export Behavior
- Movies:
  - Chooses largest direct video file in folder as main feature.
  - Writes `movie.nfo` only when TMDB ID exists.
  - Writes one STRM per movie.
- TV shows:
  - Recursively walks folders and extracts episode numbers from file names.
  - Writes `tvshow.nfo` only when TVDB ID exists.
  - Writes per-episode STRM files.
- First export:
  - Adds source to Kodi `sources.xml` as `TorBox Library`.
- Later exports:
  - Triggers `UpdateLibrary(video)`.

## Setup Server and Phone Flow
- HTTP server runs on `0.0.0.0:8765`.
- `QRDialog` displays QR code URL to access setup form on phone.
- Form posts URL/username/password.
- Server validates payload and saves credentials.
- Setup templates are centralized in `torbox_text.py`.
- Existing URL/username are prefilled in the form.
- Prefill values are HTML-escaped before injection.

## UI/Message Conventions
- User-facing strings are centralized in `torbox_text.py`.
- Keep new user-facing text in `torbox_text.py` to simplify localization and consistency.
- Keep runtime labels/notifications aligned with `APP_NAME` from `torbox_common.py`.

## Robustness and Safety Improvements Already Applied
- Guarded account query parsing in router.
- Hardened WebDAV XML parsing (missing fields, bad sizes, empty href/text).
- Fallback behavior when stream URL cannot be safely converted to authenticated form.
- Setup server lifecycle cleanup when reopened/closed.
- Setup form validation for missing fields.
- Reduced setup server log noise by overriding BaseHTTPRequestHandler log method.

## Known Environment Caveat
When editing outside Kodi runtime, static analysis often reports unresolved imports for:
- `xbmc`
- `xbmcgui`
- `xbmcplugin`
- `xbmcvfs`
This is expected in normal editor environments and not necessarily a runtime issue in Kodi.

## Important Files to Read First in Future Sessions
1. `addon.py`
2. `torbox_common.py`
3. `torbox_text.py`
4. `torbox_setup.py`
5. `torbox_library.py`
6. `torbox_webdav.py`
7. `torbox_subtitles.py`

## Practical Next Enhancements
- Add explicit module-level tests outside Kodi for pure functions (name parsing, episode extraction, overrides handling).
- Add optional localization key mapping strategy for all constants in `torbox_text.py`.
- Add structured log levels and event markers for easier troubleshooting.
- Add user-visible validation hints for malformed WebDAV URL format before submission.
- Optional: support multiple subtitle languages and language preference setting.

## Maintenance Rules
- Keep `addon.py` focused on routing/UI orchestration.
- Keep shared cross-cutting logic in `torbox_common.py`.
- Keep all UI text/templates in `torbox_text.py`.
- Avoid hardcoding user-facing text in feature modules.
- Preserve compatibility with Kodi plugin query action scheme.
